import "./styles.css";
import React, { useState } from "react";
function Suscripcion() {
  const [correo, setCorreo] = useState("");
  const [suscrito, setSuscrito] = useState(false);

  const hantleSuscribete = () => {
    setSuscrito(true);
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <input
        type="Correo"
        placeholder="Coloque su correo"
        value={correo}
        onChange={(e) => setCorreo(e.target.value)}
        style={{ marginRight: "10px" }}
      />
      <button
        onClick={hantleSuscribete}
        style={{
          backgroundColor: suscrito ? "green" : "initial",
          color: suscrito ? "white" : "inicial",
        }}
      >
        {suscrito ? "suscrito" : "suscribete"}
      </button>
    </div>
  );
}

export default Suscripcion;
